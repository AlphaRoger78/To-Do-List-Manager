﻿namespace VPLAssistPlus.Models
{
    public class TaskItem
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Status { get; set; }

        public TaskItem(int id, string title, string status)
        {
            Id = id;
            Title = title;
            Status = status;
        }
    }
}
