﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using VPLAssistPlus.Models;

namespace VPLAssistPlus
{
    public partial class MainWindow : Window
    {
        private List<TaskItem> tasks = new List<TaskItem>();
        private const string filePath = "tasks.txt";

        public MainWindow()
        {
            InitializeComponent();
            UpdateCount();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtTitle.Text))
                    throw new Exception("Task title cannot be empty.");

                if (cmbStatus.SelectedIndex == -1)
                    throw new Exception("Select a status.");

                int id = tasks.Count + 1;
                tasks.Add(new TaskItem(id, txtTitle.Text, cmbStatus.Text));

                RefreshGrid();
                ClearInputs();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            if (TaskGrid.SelectedItem is TaskItem task)
            {
                task.Title = txtTitle.Text;
                task.Status = cmbStatus.Text;
                RefreshGrid();
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (TaskGrid.SelectedItem is TaskItem task)
            {
                tasks.Remove(task);
                RefreshGrid();
            }
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            TaskGrid.ItemsSource = tasks.FindAll(
                t => t.Title.ToLower().Contains(txtSearch.Text.ToLower()));
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(filePath))
                {
                    foreach (TaskItem t in tasks)
                        sw.WriteLine($"{t.Id}|{t.Title}|{t.Status}");
                }
                MessageBox.Show("Saved successfully.");
            }
            catch
            {
                MessageBox.Show("Save failed.");
            }
        }

        private async void Load_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                await Task.Run(() =>
                {
                    if (!File.Exists(filePath)) return;

                    List<TaskItem> loaded = new List<TaskItem>();
                    foreach (string line in File.ReadAllLines(filePath))
                    {
                        string[] p = line.Split('|');
                        loaded.Add(new TaskItem(int.Parse(p[0]), p[1], p[2]));
                    }
                    tasks = loaded;
                });

                RefreshGrid();
            }
            catch
            {
                MessageBox.Show("Load failed.");
            }
        }

        private void TaskGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (TaskGrid.SelectedItem is TaskItem task)
            {
                txtTitle.Text = task.Title;
                cmbStatus.Text = task.Status;
            }
        }

        private void RefreshGrid()
        {
            TaskGrid.ItemsSource = null;
            TaskGrid.ItemsSource = tasks;
            UpdateCount();
        }

        private void UpdateCount()
        {
            txtCount.Text = "Total Tasks: " + tasks.Count;
        }

        private void ClearInputs()
        {
            txtTitle.Clear();
            cmbStatus.SelectedIndex = -1;
        }
    }
}
